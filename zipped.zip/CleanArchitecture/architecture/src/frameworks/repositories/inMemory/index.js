'use strict';

const usersRepository = require('./usersRepository');
const productsRepository = require('./productsRepository');
const ordersRepository = require('./ordersRepository');

module.exports = {
    usersRepository,
    productsRepository,
    ordersRepository,
}