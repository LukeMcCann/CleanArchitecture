'use stricts';

const inMemory = require('./inMemory');

module.exports = {
    inMemory,
}