'use strict';

module.exports = {
    users: [],
    products: [],
    orders: [],
}