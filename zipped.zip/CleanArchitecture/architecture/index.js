'use strict';

const app = require('./src/app');
app.start();